import argparse
from PIL import Image, ImageDraw, ImageFont
from PIL import Image

def bmp_to_c_array(bmp_file, c_file, width, height):
    # 打开 BMP 文件
    image = Image.open(bmp_file)
    
    # 调整图像大小到目标分辨率 (72x128)
    resized_image = image.resize((width, height), Image.ANTIALIAS)
    pixels = list(resized_image.getdata())

    # 转换为 0x12345678 格式的像素值
    pixel_data = []
    for pixel in pixels:
        r, g, b = pixel  # 每个像素的 RGB 值
        pixel_value = 0 | (r << 16) | (g << 8) | b  # 按照 ARGB 格式组合
        pixel_data.append(pixel_value)

    with open(c_file, 'w') as f:
        f.write(f"unsigned int boot_logo[{height}][{width}] = {{\n")
        
        for i in range(0, len(pixel_data), width):  # 按行分割数据
            row_data = pixel_data[i:i+width]  # 提取一行的数据
            f.write("    { " + ", ".join(f"0x{value:08X}" for value in row_data) + " },\n")
        
        f.write("};\n")

    print(f"bmp data array saved as {c_file}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="Process width and height parameters.")
    parser.add_argument('width', type=int, help='Width of the image')
    parser.add_argument('height', type=int, help='Height of the image')

    args = parser.parse_args()
    bmp_to_c_array('intput.bmp', 'output.c', args.width, args.height)