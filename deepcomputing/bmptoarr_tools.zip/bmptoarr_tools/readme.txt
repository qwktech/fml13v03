1、获取bmp的height、width，并命名为intput.bmp，放到当前路径
2、执行python bmp_to_arr.py width height
